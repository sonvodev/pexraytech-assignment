export enum ActivityStatus {
  NoActivity,
  Loading,
  Loaded,
  LoadingFailed
}