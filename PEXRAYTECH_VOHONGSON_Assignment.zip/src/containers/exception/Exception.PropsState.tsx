import { IException } from "../../models";

export interface IState {
}

export interface IProps {
  exception?: IException | null
}